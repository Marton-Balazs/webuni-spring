package hu.webuni.hr.martonBalazs.service;

import hu.webuni.hr.martonBalazs.model.Employee;

public interface EmployeeService {
	
	public int getPayRaisePercent(Employee employee);

}
